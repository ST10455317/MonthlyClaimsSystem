﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClaimSystemsGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string claimID = textBox1.Text;       
            string customerName = textBox2.Text;  
            string amount = textBox3.Text;        
            string description = textBox4.Text;   

            
            if (string.IsNullOrWhiteSpace(claimID) ||
                string.IsNullOrWhiteSpace(customerName) ||
                string.IsNullOrWhiteSpace(amount))
            {
                MessageBox.Show("⚠ Please fill in all required fields.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            MessageBox.Show(
                $"✅ Claim Submitted!\n\n" +
                $"Claim ID: {claimID}\n" +
                $"Customer: {customerName}\n" +
                $"Amount: {amount}\n" +
                $"Description: {description}",
                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
    }
}
